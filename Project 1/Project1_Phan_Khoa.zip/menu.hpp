/*********************************************************************
** Program name: menu.hpp for Project 1
** Author: Khoa Phan
** Date: April 12, 2017
** Description:  Header file for the menu function.
*********************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

bool menu(int);

#endif // !MENU