/*********************************************************************
** Program name: menu.hpp for Lab5
** Author: Khoa Phan
** Date: May 2, 2017
** Description: Header file for the Menu class.
*********************************************************************/

#ifndef MENU_HPP
#define MENU_HPP
#include "recursion.hpp"

using namespace std;

class Menu
{
private:
public:
	bool mainMenu();

protected:
};

#endif // !MENU_HPP
